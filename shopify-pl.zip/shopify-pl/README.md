# Rosental PL Shopify Theme

## Installation

Run the install command for npm 

    npm i

If you are getting any errors try to run npm install with force

    npm i --force

## Configuration

1. Copy the ``config.yml.example`` and create your own ``config.yml``
2. Use your own Themekit credentials in the ``config.yml``

3. Copy the ``.env.example`` and create your own ``.env``
4. Add either a *.shopifypreview.com URL or a custom you want to browser sync

## Shopify Development Environment

Start Development with the following command

    npm run start:dev

Tailwind and Webpack will now watch on file changes during development and
will update ``.css`` and ``.js`` files if you make change in those files

## Browser Sync 

Install Browser sync globally

    npm install -g browser-sync

Browser sync might need a sudo access to install.
So, if you are on mac, please run the following command

    sudo npm install -g browser-sync

Run browser sync to watch on file changes and update browser after a file chnage

    npm run browser-sync

## Concurrently

Install conrurrently globally

    npm install -g concurrently
    

